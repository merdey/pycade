from distutils.core import setup

setup(
    name='Pycade',
    version='0.1',
    license="LGPL",
    packages=['pycade'],
    url="http://michaelerdey.com/pycade",
    author="Michael Erdey",
    author_email="pycade@michaelerdey.com"
)